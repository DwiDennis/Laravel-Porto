<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portofolio Home</title>
    <style>
        * {
    margin: 0 ;
    padding: 0 ;
}
li {
    list-style-type: none;
    display: inline-block;
    padding: 30px 20px;
}
a {
    text-decoration: none;
    color: white;
    padding: auto;
}
.text:hover{
    font-size: 20px;
    font-weight: bold;
    background-color: yellow;
    text-decoration: underline;
    transition: 0.5s;
    text-decoration-color: red;
}
text a:hover {
    color: black;
}
body {
    background-color: black;
    text-align: center;
}
header {
    width: auto;
    height: 80px;
    background-color: steelblue;
    padding: 0 60px;
    display: flex;
    justify-content: space-between;
}
.header-right {
    font-size: 40px;
    font-weight: bold;
    padding: 20px 0;
    float: left;
}
img {
    width: 400px;
    margin: 50px;
}
h1 {
    color: cyan;
    margin-bottom: 50px;
    margin-top: 70px;
    text-align: center;
}
h2 {
    color: silver;
    margin-bottom: auto;
    margin-top: 50px;
    text-align: center;
}
p {
    color: cyan;
    font-size: 20px;
}
.Dicoding {
    color: cyan;
}
footer {
    margin-top: 50px;
    background-color: deepskyblue;
    text-align: center;
}
    </style>
</head>
<body>
    <header>
        <div class="header-right">
            C<span style="color: red;">V</span>
        </div>
        <nav>
<ul>
    <li class="text"><a href="home.blade.php">Home</a></li>
    <li class="text"><a href="About.blade.php">About Me</a></li>
    <li class="text"><a href="Portofolio.blade.php">Portofolio</a></li>
</ul>
        </nav>
    </header>
    <main>
        <div>
            <h1>MY <br> SERTIFIKAT</h1>
            <div>
                <aside>
                    <img src="Ratatype silver.jpg">
                    <img src="Dicoding sertifikat.png">
                    <br>
                    <h2>Web Project <br>
                    <img src="Web.png"></h2>
                </aside>
            </div>
        </div>
    </main>
            <footer>
                <span>&copy; make by Dennis Dwi Musti</span>
            </footer>
</body>
</html>