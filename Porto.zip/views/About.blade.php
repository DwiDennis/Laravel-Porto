<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portofolio Home</title>
    <style>
        * {
    margin: 0 ;
    padding: 0 ;
}
li {
    list-style-type: none;
    display: inline-block;
    padding: 30px 20px;
}
a {
    text-decoration: none;
    color: white;
    padding: auto;
}
.text:hover{
    font-size: 20px;
    font-weight: bold;
    background-color:yellow;
    text-decoration: underline;
    transition: 0.5s;
    text-decoration-color: red ;
}
text a:hover {
    color: black;
}

header {
    width: auto;
    height: 80px;
    background-color: steelblue;
    padding: 0 60px;
    display: flex;
    justify-content: space-between;
}
.header-right {
    font-size: 40px;
    font-weight: bold;
    padding: 20px 0;
    display: inline-block;
}
body {
    background-color: black;
}
.info {
    margin-top: 5px;
}
.Bio {
    text-align: center;
    margin-top: 10px;
    color: cyan;
    margin: 80px;
    width: auto;
    height: auto;
    border-radius: 25px;
    border: 2px solid darkcyan;
    background-color: black;
}
h2 {
    font-size: 30px;
    margin-top: 25px;
}
.pendidikan {
    text-align: center;
    margin: 80px;
    color: cyan;
    width: auto;
    height: auto;
    border-radius: 25px;
    border: 2px solid darkcyan;
    background-color: black;
}
.PENDIDIKAN1 {
    text-align: center;
    margin-top: 40px;
    font-size: 40px;
    color: cyan;
}
.pendidikan2 {
    text-align: center;
    font-size: 20px;
    margin-top: 27px;
    font-weight: bold;
    color: cyan;
}
h5 {
    text-align: center;
    color: cyan;
}
p {
    color: cyan;
}
footer {
    margin-top: 50px;
    background-color: deepskyblue;
    text-align: center;
}
    </style>
</head>
<body>
    <header>
        <div class="header-right">
            C<span style="color: red;">V</span>
        </div>
        <nav>
<ul>
    <li class="text"><a href="home.blade.php">Home</a></li>
    <li class="text"><a href="About.blade.php">About Me</a></li>
    <li class="text"><a href="Portofolio.blade.php">Portofolio</a></li>
</ul>
        </nav>
    </header>
    <hr>
    <main>
        <p>
            <div class="Bio">
                <article>
                    <h2>Informasi</h2>
                    <br>
                    <br>
                    <p>Nama Lengkap: Dennis Dwi Musti</p>
                    <p>Jenis Kelamin: Laki-Laki</p>
                    <p>Umur: 15 Tahun</p>
                    <p>Email: dennisdwi@gmail.com</p>
                    <p>Telepon: 0821-1130-2034</p>
                    <br>
                    <h4>Hobi:<h5>Main game, Baca novel, Dengerin musik, Nonton Anime</h5></h4>
                    <br>
                    <br>
                </article>
            </div>
            <div class="pendidikan">
                <article>
                    <h2 class="PENDIDIKAN1">PENDIDIKAN</h2>
                    <p class="pendidikan2">SMK WIKRAMA BOGOR</p>
                    <h5>Kelas: PPLG X-2</h5>
                    <h5>Rayon: Cisarua 3</h5>
                    <h5>Ekstrakulikuler: JOYFUL ENGLISH</h5>
                    <h5>Seni Budaya: TEATER</h5>
                    <h5>PRAMUKA</h5>
                    <p class="pendidikan2">SMPN CIAWI 01</p>
                    <p class="pendidikan2">SDN CIAWI 01</p>
                    <br>
                    <br>
                </article>
            </div>
        </p>
    </main>
    <footer>
        <span>&copy; make by Dennis Dwi Musti</span>
    </footer>
</body>
</html>